
package com.poly.Assigment;

/**
 *
 * @author Lâm Diễm Thuý
 */
import java.util.Scanner;

public class TruongPhong extends NhanVien{
   private double luongTrachNhiem;

    public TruongPhong() {
    }
   
   @Override
    public void nhap(Scanner s){
        super.nhap(s);
        System.out.println("Luong Trach Nhiem:  ");
        luongTrachNhiem = s.nextDouble();
        s.nextLine();
        
    }
   @Override
    public void xuat(){
        super.xuat();
        System.out.println("Luong Trach Nhiem: "+luongTrachNhiem);
    }
    public TruongPhong(String ma, String hoTen,String loai,double luongTrachNhiem, double luong) {
        super(ma, hoTen, "Truong Phong", luong);
        this.luongTrachNhiem = luongTrachNhiem;
    }

    public double getLuongTrachNhiem() {
        return luongTrachNhiem;
    }

    public void setLuongTrachNhiem(double luongTrachNhiem) {
        this.luongTrachNhiem = luongTrachNhiem;
    }

   @Override
    public double getThuNhap(){
       double tien = 0;
         if(luong<9000){
            return tien = luong+luongTrachNhiem;   
         }else if(luong<=15000||luong>=9000){
          return tien = luong*0.9+luongTrachNhiem;
        }else{
           return tien = luong*0.88+luongTrachNhiem;
         }
        
         }
}   
 
   
