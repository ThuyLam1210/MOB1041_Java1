/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poly.Assigment;

/**
 *
 * @author admin
 */
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;

public class DanhSachNhanVien {
   private ArrayList<NhanVien> list = new ArrayList<>();
  
   public void nhap(){
       Scanner s = new Scanner(System.in);
        list.clear();
       do{
           System.out.println("Nhap loai nhan vien (Nhan Enter de Thoat!)");
           System.out.println("Chon 1-Hanh Chinh 2-Truong Phong 3-Tiep Thi: ");
           String loai = s.nextLine();
           
           if(loai == null || loai.equals(""))
               break;
           
           int iloai = Integer.parseInt(loai);
           switch(iloai){
               case 1:
                   NhanVienHanhChinh nvhc = new NhanVienHanhChinh();
                   nvhc.nhap(s);
                   list.add(nvhc);
                   break;
               case 2:
                   TruongPhong tp = new TruongPhong();
                   tp.nhap(s);
                   list.add(tp);
                   break;
               case 3:
                   NhanVienTiepThi nvtt = new NhanVienTiepThi();
                   nvtt.nhap(s);
                   list.add(nvtt);
                   break;
           }
       }while(true);
   }
   public void xuat(){
       System.out.println("\t\t Danh Sach Nhan Vien");
       for(NhanVien nv: list){
           if(nv instanceof NhanVienHanhChinh){
               ((NhanVienHanhChinh)nv).xuat();
           }else if(nv instanceof NhanVienTiepThi){
               ((NhanVienTiepThi)nv).xuat();
            }else if(nv instanceof TruongPhong){
               ((TruongPhong)nv).xuat();
            }System.out.println("-----------------------------------------------------------------------");
        }
   }
   //Tìm và hiển thị nhân viên theo mã 
    public void timVaHienThiTheoMa(Scanner s) {
        System.out.println("Nhap Ma Nhan Vien Ban Can Tim: ");
        String ma = s.nextLine();

        NhanVien nvFound = null;
        for (NhanVien nv : list) {

            if (nv.getMa().equalsIgnoreCase(ma)) {
                nvFound = nv;
                break;
            }
        }
        if (nvFound != null) {
            System.out.println("Thong Tin Nhan Vien: ");
            nvFound.xuat();
        } else {
            System.out.println("Khong Tim Thay Ma Nhan Vien Vua Nhap!");
        }

    }
    //Xóa nhân viên theo mã
    public void xoaNhanVienTheoMa(Scanner s) {
        System.out.println("Nhap Ma Nhan Vien Can Xoa: ");
        String ma = s.nextLine();
        NhanVien nvFound = null;
        for (NhanVien nv : list) {
            if (nv.getMa().equalsIgnoreCase(ma)) {
                nvFound = nv;
                break;
            }
        }
        if (nvFound != null) {
            list.remove(nvFound);
            System.out.println("Nhan vien da duoc xoa!");
        } else {
            System.out.println("Khong tim duoc nhan vien ban can tim trong danh sach!");
        }

    }
    
    //Cập nhật thông tin nhân viên theo mã
    public void capNhapNhanVienTheoMa(Scanner s) {
        System.out.println("Nhap ma nhan vien: ");
        String ma = s.nextLine();
        NhanVien nvFound = null;
        for (NhanVien item : list) {
            if (item.getMa().equalsIgnoreCase(ma)) {
                nvFound = item;
                break;
            }
        }
        if (nvFound != null) {
            System.out.println("Nhap thong tin cap nhat cho nhan vien: ");

            if (nvFound instanceof NhanVienHanhChinh) {
                ((NhanVienHanhChinh) nvFound).nhap(s);

            } else if (nvFound instanceof TruongPhong) {
                ((TruongPhong) nvFound).nhap(s);

            } else if (nvFound instanceof NhanVienTiepThi) {
                ((NhanVienTiepThi) nvFound).nhap(s);
            }
        } else {
            System.out.println("Khong tim thay ma nhan vien");
        }

    }
    
    
    //Tìm nhân viên theo mức lương
    public void timTheoLuong(Scanner s) {
        System.out.println("Moi nhap khoang luong can tim");
        double khoangLuong = s.nextDouble();
        
                for (NhanVien x : list) {
                    if (x.getLuong() == khoangLuong) {
                    x.xuat();
                    System.out.println("--------------------------------------------------");
                }else if(x.getLuong()!= khoangLuong){
                         System.out.println("Khong tim thay nhan vien co khoang luong can tim!");
                     }
            }
         
       
    }

}
