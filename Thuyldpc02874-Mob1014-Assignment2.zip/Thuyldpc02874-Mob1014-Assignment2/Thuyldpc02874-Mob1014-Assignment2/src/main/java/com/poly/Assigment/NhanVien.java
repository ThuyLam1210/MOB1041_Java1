
package com.poly.Assigment;

/**
 *
 * @author Lâm Diễm Thuý
 * 
 */
import java.util.Scanner;

public abstract class NhanVien {
   String ma, hoTen, loai;
   double luong;

    public NhanVien() {
    }

    public NhanVien(String ma, String hoTen, String loai, double luong) {
        this.ma = ma;
        this.hoTen = hoTen;
        this.loai = loai;
        this.luong = luong;
    }
    public void nhap(Scanner s){
        System.out.println ("Nhap Ma Nhan Vien:  ");
        this.ma = s.nextLine();
        System.out.println("Nhap Ho Ten Nhan Vien: ");
        this.hoTen = s.nextLine();
        System.out.println("Nhap Loai Nhan Vien: ");
        this.loai = s.nextLine();
        System.out.println("Nhap Luong Co Ban: ");
        this.luong = s.nextDouble();
        s.nextLine();
    }
    
    public double getThuNhap(){
        double tien =0;
        if(luong>150000){
           return tien=luong-(luong*0.12);
        }else if(luong<=15000||luong>=9000){
            return tien=luong-(luong*0.1);
       }else if(luong<9000){
            return tien=luong;
       }
      return tien;
   }
    
    public void xuat(){
        System.out.println("Ma Nhan Vien:"+ma+" - Ho Ten: "+hoTen+ "- Loai Nhan Vien: "+loai+" - Luong Co Ban: "+luong+" - Thu Nhap: "+getThuNhap());
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getLoai() {
        return loai;
    }

    public void setLoai(String loai) {
        this.loai = loai;
    }

    public double getLuong() {
        return luong;
    }

    public void setLuong(double luong) {
        this.luong = luong;
    }
    
    
    
}
