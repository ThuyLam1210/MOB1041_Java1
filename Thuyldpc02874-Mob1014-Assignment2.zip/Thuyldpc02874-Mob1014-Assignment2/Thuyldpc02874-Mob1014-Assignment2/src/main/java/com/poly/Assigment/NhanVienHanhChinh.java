
package com.poly.Assigment;

/**
 *
 * @author Lâm Diễm Thuý
 */
public class NhanVienHanhChinh extends NhanVien{
    
    public NhanVienHanhChinh() {
    }

    public NhanVienHanhChinh(String ma, String hoTen, String loai, double luong) {
        super(ma, hoTen,"Hanh Chinh", luong);
    }
    
    @Override
    public double getThuNhap() {
      double tien = 0;
        if(luong<9000){
          return tien = luong;
            
     }else if(luong<=15000||luong>=9000){
           return tien = luong*0.9;
     }else{
          return tien = luong*0.88;
       }
        
   }
            
    
}
