
package com.poly.Assigment;

/**
 *
 * @author Lâm Diễm Thuý
 */
import java.util.Scanner;

public class NhanVienTiepThi extends NhanVien{
    
    private double doanhSo;
    private double hueHong;

    public NhanVienTiepThi() {
    }

  

    public NhanVienTiepThi( String ma, String hoTen,String loai, double doanhSo, double hueHong, double luong) {
        super(ma, hoTen, "Tiep Thi", luong);
        this.doanhSo = doanhSo;
        this.hueHong = hueHong;
    }
    @Override
    public void nhap(Scanner s){
        super.nhap(s);
        System.out.println("Doanh So: ");
        doanhSo = s.nextDouble();
        
        System.out.println("Hue Hong: ");
        hueHong = s.nextDouble();
        s.nextLine();
   }
    @Override
    public void xuat(){
        super.xuat();
        System.out.println("Doanh So: "+doanhSo+ " -Hue Hong: "+hueHong);
    }
    public double getDoanhSo() {
        return doanhSo;
    }

    public void setDoanhSo(double doanhSo) {
        this.doanhSo = doanhSo;
    }

    public double getHueHong() {
        return hueHong;
    }

    public void setHueHong(double hueHong) {
        this.hueHong = hueHong;
    }

    
    @Override
     public double getThuNhap() {
       double tien = 0;
        if(luong<9000){
            return tien = luong+doanhSo*hueHong;
            
        }else if(luong<=15000||luong>=9000){
           return tien = luong*0.9+doanhSo*hueHong;
        }else{
            return tien = luong*0.88+doanhSo*hueHong;
       }
      

 
    }
}
